import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { TableModel, TableItem, TableHeaderItem } from '../table/table.module';
import { IconService } from '../icon/icon.module';
//import { TableItem, TableHeaderItem, TableModel } from '../table/table.module';

@Component({
	selector: 'app-root',
	templateUrl: './app.component.html',
	styleUrls: ["./demo.scss"],
	encapsulation: ViewEncapsulation.None
})
export class AppComponent {

}