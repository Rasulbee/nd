import { HttpClient, HttpParams } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { ApprovalUrlApi } from "./approval-api";


@Injectable()
export class ApprovalService {
    constructor(private http: HttpClient) { }
    getApprovalList() {
       // return this.http.get("http://10.138.179.196:8080/approvalgroups/?orgid2=105");

          return this.http.get(ApprovalUrlApi);
          //return this.http.get("http://10.138.179.25:8083/listPageable");
          
     
        //return this.http.get("http://10.138.179.151:8080/listPageable?page=0&size=15"); 
     //  return this.http.get("http://10.138.179.132:8080/api/approvalgroups/pagination/orgid2?id=100001&limit=20&offset=1&sort=desc");
    }
  
}