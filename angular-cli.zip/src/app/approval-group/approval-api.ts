// this is fetching data from local server
export const ApprovalUrlApi = "http://localhost:1010/";

// this is for fetching data from backend server

//export const ApprovalUrlApi="http://10.138.179.26:8080/approvalgroups/?orgid2=106";