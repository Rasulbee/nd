import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApprovalGroupListComponent } from './approval-group-list.component';

describe('ApprovalGroupListComponent', () => {
  let component: ApprovalGroupListComponent;
  let fixture: ComponentFixture<ApprovalGroupListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApprovalGroupListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApprovalGroupListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
