import { Component, OnInit, ViewChild, TemplateRef } from '@angular/core';
import { TableModel, TableItem, TableHeaderItem } from '../../table/table.module';
import { ApprovalService } from './approval.service';

@Component({
	selector: 'app-approval-group-list',
	templateUrl: './approval-group-list.component.html',
	styleUrls: ['./../demo.scss']
})
export class ApprovalGroupListComponent implements OnInit {
	public simpleModel1 = new TableModel();
	//public model = new TableModel();
	topNavBrand = "Product name";
	numPages = 0;
	totlength;
	@ViewChild("customTableItemTemplate")
	private customTableItemTemplate: TemplateRef<any>;

	constructor(private approvallist: ApprovalService) {
		this.approvallist.getApprovalList().subscribe((res) => {
			console.log("Inside Approval list" + JSON.stringify(res));
			this.approvalData(res);
			console.log("######################");

		});
	}
	ngOnInit() {
		this.simpleModel1.header = [
			new TableHeaderItem({ data: "Approval Group Id" }), new TableHeaderItem({ data: "Organation Id" }), new TableHeaderItem({ data: "Name" }),
			new TableHeaderItem({ data: "created Time " }), new TableHeaderItem({ data: "modified Time" }), new TableHeaderItem({ data: "description" })

		];

		this.simpleModel1.data = []; //geting data from api and pushing into empty array;
	}
	// by useing approvalDate we are feaching the data from API call
	approvalData(res) {
		res.content.forEach((val) => {
			//below is for local server
			this.simpleModel1.data.push([new TableItem({ data: val.approvalGroupsId }), new TableItem({ data: val.organizationId2 }), new TableItem({ data: val, template: this.customTableItemTemplate }), new TableItem({ data: val.createdTs }), new TableItem({ data: val.modifiedTs }), new TableItem({ data: val.description })]);
		});
	}
	/* Header Sorting methods Start */
	simpleSort1(index: number) {
		this.sort(this.simpleModel1, index);
	}
	sort(model, index: number) {
		if (model.header[index].sorted) {
			// if already sorted flip sorting direction
			model.header[index].ascending = model.header[index].descending;
		}
		model.sort(index);
	}
	// scrollLoad is for to build an Lazy loading.
	private __appendModelData(model: TableModel, modelData: TableItem[][]) {
		modelData.map(item => model.addRow(item));
	}
	scrollLoad(model: TableModel) {
		this.__appendModelData(this.simpleModel1, this.simpleModel1.data);
		console.log("inside scrollloading second",this.simpleModel1.data.length);	
	}
	
}
