import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";


import { AppComponent } from './app.component';
import { BannerModule, BannerService } from '../banner/banner.module';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { TableModule } from '../table/table.module';
import { PaginationModule } from '../pagination/pagination.module';
import { IconService, IconModule } from '../icon/icon.module';
import { ApprovalGroupListComponent } from './approval-group/approval-group-list.component';

import { HttpClientModule } from '@angular/common/http';
import { ApprovalService } from './approval-group/approval.service';
import { TopNavModule } from '../top-nav/top-nav.module';
import { SideNavModule } from '../side-nav/side-nav.module';


@NgModule({
  declarations: [
    AppComponent,
    ApprovalGroupListComponent
  ],
  imports: [
    TableModule,
    SideNavModule,
    IconModule,
    TopNavModule,
    PaginationModule,
    HttpClientModule,
    RouterModule.forRoot([
      { path: '', component: ApprovalGroupListComponent },
      { path: 'aprovalgroup/:username', component: ApprovalGroupListComponent }
    ]),
    BrowserAnimationsModule, BrowserModule, BannerModule, TranslateModule.forRoot()
  ],
  providers: [BannerService, TranslateService, IconService, ApprovalService],

  bootstrap: [AppComponent]
})
export class AppModule { }
