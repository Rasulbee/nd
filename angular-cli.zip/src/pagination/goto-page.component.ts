import {
	Component,
	Input,
	Output,
	EventEmitter,
	ChangeDetectorRef
} from "@angular/core";

/**
 * GotoPage is a child component to the  component.
 *
 * ```html
 * <n-goto-page (selectPage)="selectPage($event)"></n-goto-page>
 * ```
 *
 * @export
 * @class GotoPage
 */
@Component({
	selector: "n-goto-page",
	// NOTE to devs: we should replace this with a template once deprication of table-goto-page is final
	templateUrl: "goto-page.component.html"
})
export class GotoPage {
	/**
	 * Variable used for creating unique ids for the input in GotoPage components.
	 * @type {number}
	 * @static
	 * @memberof GotoPage
	 */
	static gotoPageCount = 0;

	/**
	 * Variable used to track the input field value.
	 * @type {number}
	 * @memberof GotoPage
	 */
	@Input() pageNumber: number;

	/**
	 * The unique id for the GotoPage component input.
	 * @type {string}
	 * @memberof GotoPage
	 */
	@Input() id = `goToPage-${GotoPage.gotoPageCount}`;

	/**
	 * Emits the new page number.
	 * @param {number} pageNumber
	 * @memberof GotoPage
	 */
	@Output() selectPage = new EventEmitter<number>();

	/**
	 * Creates an instance of `GotoPage`.
	 * @param {ChangeDetectorRef} changeDetectorRef
	 * @memberof GotoPage
	 */
	constructor(protected changeDetectorRef: ChangeDetectorRef) {
		GotoPage.gotoPageCount++;
	}
}
