import { PaginationModel } from "./pagination.module";
import {
	Component,
	Input,
	Output,
	EventEmitter
} from "@angular/core";

/**
 * Use pagination when you have multiple pages of data to handle.
 *
 * ```html
 * <n-pagination [model]="model" (selectPage)="selectPage($event)"></n-pagination>
 * ```
 *
 * In your `selectPage()` method set the model's `currentPage` to selected page, _after_
 * you load the page.
 *
 * ```typescript
 * selectPage(page) {
 * 	// ... your code to laod the page goes here
 *
 * 	this.model.currentPage = page;
 *
 * 	// ... anything you want to do after page selection changes goes here
 * }
 *
 * @export
 * @class Pagination
 */
@Component({
	selector: "n-pagination",
	// NOTE to devs: we should replace this with a template once deprication of table-pagination is final
	templateUrl: "pagination.component.html"
})
export class Pagination {
	/**
	 * `PaginationModel` with the information about pages you're controlling.
	 *
	 * @type {Model}
	 * @memberof Pagination
	 */
	@Input() model: PaginationModel;

	/**
	 * Emits the new page number.
	 *
	 * @memberof Pagination
	 */
	@Output() selectPage = new EventEmitter<number>();

	/**
	 * Generates a list of numbers. (Python function)
	 * Used to display the correct pagination controls.
	 *
	 * @param {number} count
	 * @param {number} [offset=0]
	 * @returns {array}
	 * @memberof Pagination
	 */
	range(count: number, offset = 0) {
		return count && count > 0 ? Array(Math.ceil(count)).fill(0).map((x, i) => i + offset) : [];
	}

	/**
	 * The previous page number to navigate to, from the current page.
	 *
	 * @returns {number}
	 * @memberof Pagination
	 */
	previousPage(): number {
		return this.model.currentPage <= 1 ? 1 : this.model.currentPage - 1;
	}

	/**
	 * The next page number to navigate to, from the current page.
	 *
	 * @returns {number}
	 * @memberof Pagination
	 */
	nextPage(): number {
		const lastPage = this.lastPage();
		return this.model.currentPage >= lastPage ? lastPage : this.model.currentPage + 1;
	}

	/**
	 * The last page number to display in the pagination view.
	 *
	 * @returns {number}
	 * @memberof Pagination
	 */
	lastPage(): number {
		return Math.ceil(this.model.totalDataLength / this.model.pageLength);
	}

	/**
	 * The middle page number to display for complex paginations.
	 *
	 * @returns {number}
	 * @memberof Pagination
	 */
	middleStartPage(): number {
		return Math.floor(this.model.currentPage / 3) * 3;
	}

	/**
	 * Checks if the pagination component should display the simple view.
	 *
	 * @returns {boolean}
	 * @memberof Pagination
	 */
	isSimplePagination(): boolean {
		return Math.ceil(this.model.totalDataLength / this.model.pageLength) <= 7;
	}

	/**
	 * Checks if the pagination component should display the complex left-sided truncated view.
	 *
	 * @returns {boolean}
	 * @memberof Pagination
	 */
	isComplexLeftPagination(): boolean {
		return !this.isSimplePagination() && this.model.currentPage <= 5;
	}

	/**
	 * Checks if the pagination component should display the complex right-sided truncated view.
	 *
	 * @returns {boolean}
	 * @memberof Pagination
	 */
	isComplexRightPagination(): boolean {
		// if the page number is less than 6, it has to be in the left.
		return !this.isSimplePagination() && this.model.currentPage >= this.lastPage() - 4 && this.model.currentPage >= 6;
	}

	/**
	 * Checks if the pagination component should display the complex both-sided truncated view.
	 *
	 * @returns {boolean}
	 * @memberof Pagination
	 */
	isComplexMiddlePagination(): boolean {
		return !this.isSimplePagination() && !this.isComplexLeftPagination() && !this.isComplexRightPagination();
	}
}
