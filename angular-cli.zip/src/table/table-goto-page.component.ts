import { Component } from "@angular/core";
import { GotoPage } from "../pagination/pagination.module";

/**
 * TableGotoPage is a child component to the Table component.
 *
 * @deprecated from Neutrino 2.0 in favor of `n-goto-page` from `Pagination` module.
 *
 * Add `PaginationModule` in addition to `TableModel` and use `n-goto-page` instead. You can keep
 * everything else as is.
 *
 * ```html
 * <n-table-goto-page (selectPage)="selectPage($event)"></n-table-goto-page>
 * ```
 *
 * becomes
 *
 * ```html
 * <n-goto-page (selectPage)="selectPage($event)"></n-goto-page>
 * ```
 * @export
 * @class TableGotoPage
 */
@Component({
	selector: "n-table-goto-page",
	templateUrl: "../pagination/goto-page.component.html"
})
export class TableGotoPage extends GotoPage { }
