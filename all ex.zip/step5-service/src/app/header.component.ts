import { Component, OnInit } from "@angular/core";
import { HclServices } from "./hero.service";

@Component({
    selector : 'app-header',
    template : `
    <h1>Application Heading</h1>
        <nav class="navbar navbar-light navbar-expand-lg">
            <ul class="navbar-nav">
                <li class="nav-item" *ngFor="let hero of data?.heroes" >
                    <a class="nav-link" href="/{{ hero.name }}">{{ hero.name }}</a>
                </li>
            </ul>
        </nav>
    `
})
export class HeaderComponent{
    /*
    hs:HclServices;
    data;
    constructor(){}
    ngOnInit(){
        this.hs = new HclServices();
        this.data = this.hs.getData();
    }
    */
    data;
    constructor(private hs:HclServices){
           // EMPTY
    }
    ngOnInit(){
        this.hs.getData().subscribe( (res) => {
            this.data = res
        });    
   }

}