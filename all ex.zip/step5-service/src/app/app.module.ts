import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { GridComponent } from './grid.component';
import { HeaderComponent } from './header.component';
import { HclServices } from './hero.service';

@NgModule({
  declarations: [ AppComponent, GridComponent, HeaderComponent ],
  imports: [ BrowserModule, HttpClientModule ],
  providers : [HclServices],
  bootstrap: [AppComponent]
})
export class AppModule { }
