import { Component } from "@angular/core";
import { HclServices } from "./hero.service";

@Component({
    selector : 'app-grid',
    template : `
    <table class="table">
      <thead class="thead-dark">
        <tr>
          <th>SL #</th>
          <th>Title</th>
          <th>Poster</th>
          <th>Full Name</th>
          <th>Release Date</th>
          <th>Power</th>
          <th>Earning</th>
          <th>Place of Birth</th>
        </tr>
      </thead>
      <tbody>
        <tr *ngFor="let hero of data?.heroes">
          <td>{{ hero.id }}</td>
          <td>{{ hero.name | titlecase }}</td>
          <td><img [src]="'assets/'+hero.image.url" [alt]="hero.name" width="50"></td>
          <td>{{ hero.biography['full-name'] }}</td>
          <td>{{ hero.biography['release-date'] | date : 'dd-MMMM-yyyy' }}</td>
          <td>{{ hero.powerstats.power }}</td>
          <td>{{ hero.biography.earning | currency : 'Rs ' : 'code' : '3.2-3' }}</td>
          <td>{{ hero.biography['place-of-birth'] }}</td>
        </tr>
      </tbody>
    </table>
    `
})
export class GridComponent{
    data;
    constructor(private hs:HclServices){}
    ngOnInit(){
        this.hs.getData().subscribe( (res) => {
            this.data = res
        });  
    }
}