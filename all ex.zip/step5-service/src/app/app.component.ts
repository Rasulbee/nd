import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template : `
  <app-header></app-header>
  <app-grid></app-grid>
  `
})
export class AppComponent {
  title = 'step5-service';
}
