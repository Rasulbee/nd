import { Component } from "@angular/core";
import { summaryFileName } from "@angular/compiler/src/aot/util";

@Component({
  selector: 'app-root',
  template: `
  <h1>{{ title.length * 2 }}</h1>
  <h1>{{ title }}</h1>
  <h2 [innerHTML]="title" ></h2>
  <h2 [textContent]="title" ></h2>
  <h2 [innerText]="title" ></h2>
  <h1 [class]="boxclass">{{ title }}</h1>
  <h1 bind-innerHTML="title"></h1>
  <img src="assets/images/rajani.jpg" alt="Rajani">
  <h2>{{ sayName() }}</h2>
  <h2 [innerHTML]="sayName()"></h2>
  <h2 bind-innerHTML="sayName()"></h2>
  `,
  styles : [`
    .box{
      background-color : red;
    }
  `]
})
export class AppComponent {
  title = 'Welcome to your life !!!';
  boxclass = "box"
  sayName(){
    return "there's no turning back"
  }
}
