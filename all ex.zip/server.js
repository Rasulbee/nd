var express = require("express");
var cors = require("cors");
var hd = require(__dirname+"/data.json");
var app = express();
var data = hd;
console.log(data);
app.use(cors());
app.get("/", function(req, res){
    res.json(data)
});
app.listen(1010);
console.log("server is now live on localhost:1010");