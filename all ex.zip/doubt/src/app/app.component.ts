import { Component, OnInit } from '@angular/core';
import { HeroService } from './hero.service';

@Component({
  selector: 'app-root',
  template : `
    <ul>
      <li *ngFor="let hero of title?.hd">{{ hero }}</li>
    </ul>
  `
})
export class AppComponent{
  title;
  constructor(private hs:HeroService){}
  ngOnInit(){
    this.hs.getData().subscribe( (res) => {
        this.title = res
    });
  }
}
