import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template : `
  <input type="text" [(ngModel)]="title" >
  <h1>Main Component : Count = {{ count }}</h1>
  <hr>
  <!-- app-child>{{ title }}</app-child-->
  <app-child [blr]="title" (childCompEvent)="callbackfun($event)">
    <h1>{{title}}</h1>
    <h3>Heading Three</h3>
    <ul class="first">
      <li class="box">List Item 1</li>
      <li>List Item 1</li>
    </ul>
    <ul class="second">
      <li>List Item 2</li>
      <li>List Item 2</li>
    </ul>
  </app-child>
  `
})
export class AppComponent {
  title = 'Hello from app component';
  count = 0;

  callbackfun(evt){
   this.count = evt
  }
}
