import { Component, Input, Output, EventEmitter } from "@angular/core";

@Component({
    selector : 'app-child',
    template : `
    <div class="box">
        <input type="number" #num>
        <hr>
        <h1>Child Component</h1>
        <ng-content select="h1"></ng-content>
        <hr>
        <ng-content select="h3"></ng-content>
        <hr>
        <ng-content select=".second"></ng-content>
        <ng-content select=".first"></ng-content>
        <hr>
        <ng-content select="h1"></ng-content>
        <hr>
        <h5>{{ hcl }}</h5>
        <button (click)="compDispatchEvent(num.value)">Click Me</button>
        </div>
    `,
    styles : [`
        .box{
            border : 5px solid red;
            background-color : silver;
            width : 80%
        }
    `]
})
export class ChildComponent{
   @Input('blr') hcl = "Child Component Data";
   @Output() childCompEvent:EventEmitter<any> = new EventEmitter();
   compDispatchEvent(val){
       // alert("you clicked the button");
       this.childCompEvent.emit(val);
   }
}