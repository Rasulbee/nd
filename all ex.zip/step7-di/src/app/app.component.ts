import { Component } from '@angular/core';
import { AppService } from './app.service';

@Component({
  selector: 'app-root',
  template : `
    <h1>{{ title }}</h1>
    <hr>
    <input type="text" [(ngModel)]="herolist[0]">
    <ul>
      <li *ngFor="let hero of herolist" >{{ hero }}</li>
    </ul>
    <app-one-comp></app-one-comp>
    <app-two-comp></app-two-comp>
  `
})
export class AppComponent {
  title = 'DI in Angular';
  /*
  */
  herolist = [];
  constructor(private appServ:AppService){}
  ngOnInit(){
    this.herolist = this.appServ.getData();
  }
}
