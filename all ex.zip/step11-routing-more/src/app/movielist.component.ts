import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-movielist',
  template: `
    <h1>
      movielist works!
    </h1>
  `,
  styles: []
})
export class MovielistComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
