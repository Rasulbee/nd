import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <ul>
      <li> <a [routerLink]="['welcome']" > Welcome </a></li>
      <li> <a [routerLink]="['herolist']" >Hero List </a></li>
      <li> <a [routerLink]="['movielist']" >Movie List </a></li>
      <li> <a [routerLink]="['addhero']" >Add Hero </a></li>
    </ul>
    <router-outlet></router-outlet>
  `
})
export class AppComponent {

}
