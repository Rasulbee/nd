import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { WelcomeComponent } from './welcome.component';
import { MovielistComponent } from './movielist.component';
import { HerolistComponent } from './herolist.component';
import { AddheroComponent } from './addhero.component';
import { RouterModule } from '@angular/router';

@NgModule({
  declarations: [
    AppComponent,
    WelcomeComponent,
    MovielistComponent,
    HerolistComponent,
    AddheroComponent
  ],
  imports: [
    BrowserModule, RouterModule.forRoot([
      {path:"", component:WelcomeComponent},
      {path:"herolist", component:HerolistComponent},
      {path:"movielist", component:MovielistComponent},
      {path:"addhero", component:AddheroComponent},
      {path:"**", redirectTo:"", pathMatch:"full" },
    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
