import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addhero',
  template: `
    <h1>
      addhero works!
    </h1>
  `,
  styles: []
})
export class AddheroComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
