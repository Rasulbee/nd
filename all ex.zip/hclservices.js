let express = require("express");
let cors = require("cors");
let data = require(__dirname+"/heroes.json");
let app = express();

app.use(cors());

app.get("/data", function(request, response){
    response.json(data);
});

app.listen(2020,function(error){
    if(error){
        console.error("Error : ",error)
    }else{
        console.log("Server is live on localhost:2020")
    }
})

