import { Injectable } from "@angular/core";
import { Resolve, ActivatedRouteSnapshot } from "@angular/router";
import { HeroServices } from "./hero.service";

@Injectable()
export class SingleHeroResolverservice implements Resolve<any>{
    constructor( private hs:HeroServices){}
    // resolve( route:ActivatedRouteSnapshot ){
    resolve( route:ActivatedRouteSnapshot ){
       // console.log(route.params['hi'])
       console.log(route.queryParams["hid"])
        return this.hs.getSingleData(route.queryParams["hid"])
    }

}