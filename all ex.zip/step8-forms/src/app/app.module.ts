import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { TemplateFormComponent } from './templateform.component';
import { ReactiveFormComponent } from './reactiveform.component';
import { ReactiveFormBuilderComponent } from './reactive-formbuilder.component';

@NgModule({
  declarations: [ AppComponent, TemplateFormComponent, ReactiveFormComponent, ReactiveFormBuilderComponent ],
  imports: [ BrowserModule, FormsModule, ReactiveFormsModule ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
