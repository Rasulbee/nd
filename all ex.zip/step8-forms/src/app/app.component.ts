import { Component } from '@angular/core';
@Component({
  selector: 'app-root',
  template : `
  <h1>Template Driven Form</h1>
  <app-template-form></app-template-form>
  <hr>
  <h1>Reactive Form Form</h1>
  <app-reactive-form></app-reactive-form>
  <hr>
  <h1>Reactive Form Form with Builder</h1>
  <app-reactive-form-builder></app-reactive-form-builder>
  `
})
export class AppComponent {
  title = 'Template Forms';
}
