import { Component, Input } from "@angular/core";

@Component({
    selector : "app-test",
    template : `
    <h1>
        <li> 
            {{ data }}
        </li>
    </h1>
    `
})
export class TestComponent{
    @Input()data = "default"
}