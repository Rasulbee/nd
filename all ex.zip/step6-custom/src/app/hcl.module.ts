import { NgModule } from "@angular/core";
import { GenPipe } from "./gen.pipe";
import { HCLDirective } from "./hcl.directive";
import { TestComponent } from "./test.component";

@NgModule({
    declarations : [GenPipe, HCLDirective, TestComponent],
    exports : [GenPipe, HCLDirective, TestComponent]
})
export class HCLModule{

}