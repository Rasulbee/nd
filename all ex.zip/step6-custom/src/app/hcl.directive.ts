import { Directive, ElementRef, Input } from "@angular/core";

@Directive({
    selector : '[hcl]'
})
export class HCLDirective{
    @Input() hcl = '';
    constructor(private elref:ElementRef){ }
    ngOnInit(){
        let temp = this.elref.nativeElement.innerHTML;
        this.elref.nativeElement.outerHTML = "<"+this.hcl+">"+temp+"</"+this.hcl+">";
    } 
}