import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { HCLModule } from './hcl.module';

@NgModule({
  declarations: [ AppComponent ],
  imports: [ BrowserModule, HCLModule ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
