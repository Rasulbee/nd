import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  template: `
    <h1>
      home works!
    </h1>
    <hr>
    <!--ul>
      <li> <a routerLink="">Home</a> </li>
      <li> <a routerLink="batman">Batman</a> </li>
      <li> <a routerLink="superman">Superman</a> </li>
      <li> <a routerLink="ironman">Ironman</a> </li>
      <li> <a routerLink="spiderman">Spiderman</a> </li>
      <li> <a routerLink="Joker">Joker</a> </li>
    </ul-->
    <hr>
  `,
  styles: []
})
export class HomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
