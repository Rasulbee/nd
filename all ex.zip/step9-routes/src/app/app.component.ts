import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template : `
  <ul>
    <li> <a href="">Home</a> </li>
    <li> <a href="batman">Batman</a> </li>
    <li> <a href="superman">Superman</a> </li>
    <li> <a href="ironman/qty">Ironman</a> </li>
    <li> <a href="spiderman">Spiderman</a> </li>
    <li> <a href="Joker">Joker</a> </li>
  </ul>
  <hr>
  <ul>
      <li> <a routerLink="" routerLinkActive="selectedlink" [routerLinkActiveOptions]="{exact:true}" >Home</a> </li>
      <li> <a routerLink="batman" routerLinkActive="selectedlink" >Batman</a> </li>
      <li> <a routerLink="superman" routerLinkActive="selectedlink" >Superman</a> </li>
      <li> <a routerLink="ironman" routerLinkActive="selectedlink" >Ironman</a> </li>
      <li> <a routerLink="spiderman" routerLinkActive="selectedlink" >Spiderman</a> </li>
      <li> <a routerLink="Joker" routerLinkActive="selectedlink" >Joker</a> </li>
  </ul>
  <hr>
  <ul>
      <li> <a [routerLink]="['']" routerLinkActive="selectedlink" [routerLinkActiveOptions]="{exact:true}" >Home</a> </li>
      <li> <a [routerLink]="['batman']" routerLinkActive="selectedlink" >Batman</a> </li>
      <li> <a [routerLink]="['superman']" routerLinkActive="selectedlink" >Superman</a> </li>
      <li> <a [routerLink]="['ironman']" routerLinkActive="selectedlink" >Ironman</a> </li>
      <li> <a [routerLink]="['spiderman']" routerLinkActive="selectedlink" >Spiderman</a> </li>
      <li> <a [routerLink]="['Joker']" routerLinkActive="selectedlink" >Joker</a> </li>
  </ul>
  <router-outlet></router-outlet>
  `,
  styles:[`
    .selectedlink{
      background-color: crimson
    }
  `]
})
export class AppComponent {
  title = 'step9-routes';
}
