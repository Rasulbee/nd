import { Component, OnInit } from "@angular/core";

@Component({
	selector: "app-home-root",
	template: ``
})
export class HomeComponent {

}
