import { Component, OnInit, ViewEncapsulation } from "@angular/core";
import { TranslateService } from "@ngx-translate/core";
import { Router, NavigationEnd, NavigationStart } from "@angular/router";
import { HcModeChecker, IconService } from "./../../src";
import "rxjs/add/operator/filter";

const en = require("./../../src/i18n/en.json");
const de = require("./../../src/i18n/de.json");
const es = require("./../../src/i18n/es.json");
const fr = require("./../../src/i18n/fr.json");
const it = require("./../../src/i18n/it.json");
const ja = require("./../../src/i18n/ja.json");
const ko = require("./../../src/i18n/ko.json");
const ptBr = require("./../../src/i18n/pt-BR.json");
const zhHans = require("./../../src/i18n/zh-Hans.json");
const zhHant = require("./../../src/i18n/zh-Hant.json");

@Component({
	selector: "app-root",
	template: `
	<header class="p-demo-header text--center">
		<h1>Neutrino</h1>
		<h2>A componentized <em>Angular</em> implementation of the Watson Customer Engagement design guide.</h2>
		<a class="btn--icon-white" href="https://github.ibm.com/peretz/neutrino">
			<n-icon icon="build" color="white" size="sm"></n-icon>
			Project
		</a>
		<a class="btn--icon-white" href="https://github.ibm.com/peretz/neutrino/wiki/Style-guide">
			<n-icon icon="form_opt_in" color="white" size="sm"></n-icon>
			Code style guide
		</a>
		<a class="btn--icon-white" href="documentation/">
			<n-icon icon="document" color="white" size="sm"></n-icon>
			Documentation
		</a>
		<a class="btn--icon-white" href="http://billboard1.fyre.ibm.com/">
			<n-icon icon="preview" color="white" size="sm"></n-icon>
			Billboard
		</a>
		<a class="btn--icon-white" href="https://peretz.slack.com/messages/C6DS43Y5N">
			<n-icon icon="collaborate" color="white" size="sm"></n-icon>
			Send feedback
		</a>
		<a class="btn--icon-white" href="https://peretz.slack.com/messages/C6DS43Y5N">
			<n-icon icon="query" color="white" size="sm"></n-icon>
			Ask a question
		</a>
	</header>
	<main class="p-container">
	<aside class="p-demo-sidebar" role="complementary">
		<label for="languageSelector">Component language</label>
		<n-dropdown
		id="languageSelector"
		placeholder="Select language"
		(selected)="onSelectLanguage($event)">
			<n-dropdown-list [items]="languages">
			</n-dropdown-list>
		</n-dropdown>
		<nav class="p-demo-sidenav">
			<label class="search_group">
				<svg class="search_icon" aria-hidden="true">
					<use href="#search_16"></use>
				</svg>
				<input
					#demo_search
					type="search"
					(keyup)="search($event)"
					class="input-field"
					placeholder="Filter"
					aria-label="filter components">
				<button
					class="close"
					type="reset"
					aria-label="Reset search"
					(click)="demo_search.value = ''; search($event);">
					<svg class="close_icon">
						<use href="#x_16"></use>
					</svg>
				</button>
			</label>
			<n-list-group [items]="filteredItems" [listTpl]="item" (selected)="onSelect($event)">
				<ng-template #item let-item="item">
					<a routerLink="{{item.link}}">{{item.content}}</a>
				</ng-template>
			</n-list-group>
		</nav>
	</aside>
	<div class="p-demo-container">
		<div class="main-banner-placeholder"></div>
		<router-outlet></router-outlet>
	</div>
	</main>
	<n-modal-placeholder></n-modal-placeholder>
	<n-dialog-placeholder></n-dialog-placeholder>
	<n-sprite sprite="alerts_status"></n-sprite>
	<n-sprite sprite="animations"></n-sprite>
	<n-sprite sprite="arrows_chevrons"></n-sprite>
	<n-sprite sprite="brands"></n-sprite>
	<n-sprite sprite="calculator"></n-sprite>
	<n-sprite sprite="core_set"></n-sprite>
	<n-sprite sprite="cursors"></n-sprite>
	<n-sprite sprite="disabled"></n-sprite>
	<n-sprite sprite="ecommerce"></n-sprite>
	<n-sprite sprite="emoticons"></n-sprite>
	<n-sprite sprite="formatting"></n-sprite>
	<n-sprite sprite="gestures"></n-sprite>
	<n-sprite sprite="ibm_logo"></n-sprite>
	<n-sprite sprite="market_segments_activities"></n-sprite>
	<n-sprite sprite="market_segments_browser_os_mobile"></n-sprite>
	<n-sprite sprite="market_segments_demographics"></n-sprite>
	<n-sprite sprite="market_segments_occasions_seasons"></n-sprite>
	<n-sprite sprite="market_segments_occupations"></n-sprite>
	<n-sprite sprite="market_segments_segments"></n-sprite>
	<n-sprite sprite="market_segments_store_users"></n-sprite>
	<n-sprite sprite="mobile_controls"></n-sprite>
	<n-sprite sprite="playback_controls"></n-sprite>
	<n-sprite sprite="tables"></n-sprite>
	<n-sprite sprite="top_nav_bar"></n-sprite>
	<n-sprite sprite="watson_shell"></n-sprite>
	<n-sprite sprite="window_controls"></n-sprite>
	`,
	styleUrls: ["./demo.scss"],
	encapsulation: ViewEncapsulation.None
})
export class AppComponent implements OnInit {
	public navItems = [
		{
			content: "Forms",
			link: "/forms",
			selected: false
		},
		{
			content: "Iconography",
			link: "/icon",
			selected: false
		},
		{
			content: "Popover",
			link: "/popover",
			selected: false
		},
		{
			content: "Tooltip",
			link: "/tooltip",
			selected: false
		},
		{
			content: "Tabs",
			link: "/tabs",
			selected: false
		},
		{
			content: "List group",
			link: "/list-group",
			selected: false
		},
		{
			content: "Table",
			link: "/table",
			selected: false
		},
		{
			content: "Tree view",
			link: "/tree-view",
			selected: false
		},
		{
			content: "Drop-down",
			link: "/dropdown",
			selected: false
		},
		{
			content: "Button menu",
			link: "/button-menu",
			selected: false
		},
		{
			content: "Top-nav",
			link: "/top-nav",
			selected: false
		},
		{
			content: "Side-nav",
			link: "/side-nav",
			selected: false
		},
		{
			content: "Modal",
			link: "/modal",
			selected: false
		},
		{
			content: "Banners",
			link: "/banner",
			selected: false
		},
		{
			content: "Calendar",
			link: "/calendar",
			selected: false
		},
		{
			content: "Combo box",
			link: "/combobox",
			selected: false
		},
		{
			content: "Chart",
			link: "/chart",
			selected: false
		},
		{
			content: "Condition builder",
			link: "/condition-builder",
			selected: false
		},
		{
			content: "Progress indicator",
			link: "/progress-indicator",
			selected: false
		},
		{
			content: "Step wizard",
			link: "/step-wizard",
			selected: false
		},
		{
			content: "Pagination",
			link: "/pagination",
			selected: false
		}
	].sort((a, b) => {
		if (a.content > b.content) {
			return 1;
		} else if (a.content < b.content) {
			return -1;
		}
		return 0;
	});
	languages = [
		{
			content: "en",
			selected: true
		}
	];
	public filteredItems = this.navItems;
	private previousItem = null;
	constructor (private router: Router, private translate: TranslateService, private iconService: IconService) {
		this.translate.setDefaultLang("en");
		this.translate.use("en");
		this.translate.setTranslation("en", en);
		this.translate.setTranslation("de", de);
		this.translate.setTranslation("es", es);
		this.translate.setTranslation("fr", fr);
		this.translate.setTranslation("it", it);
		this.translate.setTranslation("ja", ja);
		this.translate.setTranslation("ko", ko);
		this.translate.setTranslation("pt-BR", ptBr);
		this.translate.setTranslation("zh-Hans", zhHans);
		this.translate.setTranslation("zh-Hant", zhHant);

		this.languages = this.translate.getLangs().map(lang => ({
			content: lang,
			selected: lang === "en"
		}));

		IconService.setBaseURL("http://s3-api.us-geo.objectstorage.softlayer.net/icons/");
	}

	ngOnInit() {
		this.router.events.filter(x => x instanceof NavigationEnd).subscribe(x => {
			if (x["url"] === "/" && this.previousItem) {
				this.previousItem.selected = false;
			}
		});

		this.router.events.filter(x => x instanceof NavigationStart).subscribe(x => {
			if (this.previousItem) {
				this.previousItem.selected = false;
			}
			let item = this.navItems.find(y => y.link === x["url"]);
			if (item) {
				item.selected = true;
			}
			this.previousItem = item;
		});

		HcModeChecker();
	}

	search(ev) {
		let term = ev.target.value;
		this.filteredItems = this.navItems.filter(item => {
			return new RegExp(term, "gi").test(item.content);
		});
	}

	onSelect({item}) {
		if (this.previousItem) {
			this.previousItem.selected = false;
		}
		this.previousItem = item;
		item.selected = true;
		this.router.navigate([item.link]); // do we need to remove this since we have routerLink already?
											// also, replace selected with routerLinkActive?
											// https://angular.io/docs/ts/latest/api/router/index/RouterLinkActive-directive.html
	}

	onSelectLanguage(event) {
		if (event.item.selected) {
			this.translate.use(event.item.content);
		}
	}
}
