import {
	Component,
	OnInit
} from "@angular/core";

import { TableModel } from "../../../src/table/table.module";
import { PaginationModel } from "./../../../src/pagination/pagination-model.class";


@Component({
	selector: "app-table-demo",
	template: `
	<h1 class="p-demo-heading">Pagination</h1>

	<h2 class="p-demo-section">Pagination model</h2>

	<n-label>
		Page length
		<input type="number" [(ngModel)]="paginationModel.pageLength">
	</n-label>
	<n-label>
		Total data length
		<input type="number" [(ngModel)]="paginationModel.totalDataLength">
	</n-label>
	Selected page: {{selectedPage}}

	<footer class="table-footer--pagination">
		<n-pagination [model]="paginationModel" (selectPage)="selectPage($event)"></n-pagination>
		<n-goto-page (selectPage)="selectPage($event)"></n-goto-page>
	</footer>

	<h2 class="p-demo-section">Table model</h2>

	<n-label>
		Page length
		<input type="number" [(ngModel)]="tableModel.pageLength">
	</n-label>
	<n-label>
		Total data length
		<input type="number" [(ngModel)]="tableModel.totalDataLength">
	</n-label>
	Selected page: {{selectedTablePage}}

	<footer class="table-footer--pagination">
		<n-pagination [model]="tableModel" (selectPage)="selectTablePage($event)"></n-pagination>
		<n-goto-page (selectPage)="selectTablePage($event)"></n-goto-page>
	</footer>
	`
})
export class PaginationDemo implements OnInit {
	tableModel = new TableModel();
	paginationModel = new PaginationModel();

	selectedPage: number;
	selectedTablePage: number;


	ngOnInit() {
		// pagination model
		this.paginationModel.pageLength = 4;
		this.paginationModel.totalDataLength = 20;

		// table model
		this.tableModel.pageLength = 4;
		this.tableModel.totalDataLength = 20;

		this.selectPage(1);
		this.selectTablePage(1);
	}

	selectPage(page) {
		console.log(page, "from pagination model");
		this.selectedPage = page;
		this.paginationModel.currentPage = page;
	}

	selectTablePage(page) {
		console.log(page, "from table model");
		this.selectedTablePage = page;
		this.tableModel.currentPage = page;
	}
}
