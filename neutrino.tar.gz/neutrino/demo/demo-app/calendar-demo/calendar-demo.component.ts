import { Component, OnInit } from "@angular/core";

import { DateTimeModel } from "./../../../src/calendar/date-time-model.class";

@Component({
	selector: "calendar-demo",
	template: `
	<h1>Calendar</h1>

	<n-radio-group [(ngModel)]="monthMode" class="mode-selection">
		Selection mode:&nbsp;&nbsp;&nbsp;
		<n-radio value="single">Single</n-radio>
		<n-radio value="range">Range</n-radio>
	</n-radio-group>
	<div style="width: 280px;">
		<n-calendar-month-view [model]="monthViewModel" [mode]="monthMode"></n-calendar-month-view>
	<div>

	<n-radio-group [(ngModel)]="monthMode2" class="mode-selection">
		Selection mode:&nbsp;&nbsp;&nbsp;
		<n-radio value="single">Single</n-radio>
		<n-radio value="range">Range</n-radio>
	</n-radio-group>
	<div style="width: 564px;">
		<n-calendar-month-view
			[model]="monthViewModel"
			[monthCount]="2"
			[mode]="monthMode2">
		</n-calendar-month-view>
	<div>

	<n-radio-group [(ngModel)]="monthsMode" class="mode-selection">
		Selection mode:&nbsp;&nbsp;&nbsp;
		<n-radio value="single">Single</n-radio>
		<n-radio value="range">Range</n-radio>
	</n-radio-group>
	<div style="width: 1046px;">
		<n-calendar-months-view [model]="monthsViewModel" [mode]="monthsMode"></n-calendar-months-view>
	</div>

	<n-radio-group [(ngModel)]="quarterMode" class="mode-selection">
		Selection mode:&nbsp;&nbsp;&nbsp;
		<n-radio value="single">Single</n-radio>
		<n-radio value="range">Range</n-radio>
	</n-radio-group>
	<div style="width: 1046px;">
		<n-calendar-quarter-view [model]="quarterViewModel" [mode]="quarterMode"></n-calendar-quarter-view>
	</div>

	<n-radio-group [(ngModel)]="yearMode" class="mode-selection">
		Selection mode:&nbsp;&nbsp;&nbsp;
		<n-radio value="single">Single</n-radio>
		<n-radio value="range">Range</n-radio>
	</n-radio-group>
	<div style="width: 1046px;">
		<n-calendar-year-view [model]="yearViewModel" [mode]="yearMode"></n-calendar-year-view>
	</div>

	<label for="calendarViewSelector">View</label>
	<n-dropdown
	id="calendarViewSelector"
	placeholder="Select calendar view"
	(selected)="onSelectView($event)">
		<n-dropdown-list [items]="calendarViews">
		</n-dropdown-list>
	</n-dropdown>
	<n-radio-group [(ngModel)]="calendarMode" class="mode-selection">
		Selection mode:&nbsp;&nbsp;&nbsp;
		<n-radio value="single">Single</n-radio>
		<n-radio value="range">Range</n-radio>
	</n-radio-group>
	<div style="width: 1046px;">
		<n-calendar
			[view]="calendarView"
			[model]="calendarModel"
			[mode]="calendarMode"
			[monthCount]="calendarMonthCount"
			(dateSelected)="onDateSelected($event)"></n-calendar>
	</div>
	`,
	styles: [`
	.mode-selection {
		display: inline-flex;
		margin: 0;
	}
	`]
})

export class CalendarDemo implements OnInit {
	monthViewModel = new DateTimeModel();
	monthMode = "range";
	monthMode2 = "range";
	monthsViewModel = new DateTimeModel();
	monthsMode = "range";
	quarterViewModel = new DateTimeModel();
	quarterMode = "range";
	yearViewModel = new DateTimeModel();
	yearMode = "range";
	calendarModel = new DateTimeModel();
	calendarMode = "range";
	calendarMonthCount = 1;
	calendarView = "month";
	calendarViews = [
		{
			content: "month",
			selected: true
		},
		{
			content: "month2",
			selected: false
		},
		{
			content: "months",
			selected: false
		},
		{
			content: "quarter",
			selected: false
		},
		{
			content: "year",
			selected: false
		}
	];
	date = new Date();

	selectedDate;

	counter = this.date.getMonth();

	todayPlus5 = new Date(this.date.getFullYear(), this.date.getMonth() + 4, this.date.getDate() + 5);
	todayPlusYear = new Date(this.date.getFullYear() + 1, this.date.getMonth(), this.date.getDate());

	constructor() {
		const disabledDay = new Date(2018, 6, 3);
		const disabledRangeStart = new Date(2016, 0, 0);
		const disabledRangeEnd = new Date(2017, 5, 3);

		this.monthViewModel.disabledDates = [disabledDay];
		this.monthsViewModel.disabledDates = [[disabledRangeStart, disabledRangeEnd]];
		this.quarterViewModel.disabledDates = [[disabledRangeStart, disabledRangeEnd]];
		this.yearViewModel.disabledDates = [[disabledRangeStart, disabledRangeEnd]];
	}

	ngOnInit() {
		this.monthViewModel.startDate = this.date;
		this.monthViewModel.endDate = this.todayPlus5;

		this.monthsViewModel.startDate = this.date;
		this.monthsViewModel.endDate = this.todayPlus5;

		this.quarterViewModel.startDate = this.date;
		this.quarterViewModel.endDate = this.todayPlus5;

		this.yearViewModel.startDate = this.date;
		this.yearViewModel.endDate = this.todayPlusYear;
	}

	onSelectView(event) {
		if (!event.item.selected) {
			return;
		}

		if (event.item.content === "month2") {
			this.calendarMonthCount = 2;
			this.calendarView = "month";
		} else {
			this.calendarMonthCount = 1;
			this.calendarView = event.item.content;
		}
	}

	onDateSelected(event) {
		console.log(event);
	}
}
