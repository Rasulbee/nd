import { Component, HostListener } from "@angular/core";

@Component({
	selector: "app-progress-indicator-demo",
	template: `
		<h1 class="p-demo-heading">Progress Indicator</h1>

		<h2 class="p-demo-section">Default</h2>

		<n-label>
			Value
			<input style="width: 340px" type="number" [(ngModel)]="value1">
		</n-label>
		<div class="resizable-container">
			<n-progress-indicator [value]="value1"></n-progress-indicator>
		</div>

		<h2 class="p-demo-section">With no percentage and custom text</h2>

		<n-label>
			Value
			<input style="width: 340px" type="number" [(ngModel)]="value2">
		</n-label>
		<div class="resizable-container">
			<n-progress-indicator [value]="value2" [showPercentage]="false">
				Custom text
			</n-progress-indicator>
		</div>
	`,
	styleUrls: ["./progress-indicator-demo.component.scss"]
})
export class ProgressIndicatorDemo {
	value1 = 25;
	value2 = 25;
}
