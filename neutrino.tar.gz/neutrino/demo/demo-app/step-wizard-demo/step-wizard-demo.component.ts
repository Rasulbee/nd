import { Component } from "@angular/core";

@Component({
	selector: "app-step-wizard-demo",
	template: `
	<h1 class="p-demo-heading">Step wizard</h1>
	<h2>Linear</h2>
	<n-step-wizard [orientation]="orientation" [steps]="steps" [linear]="true"></n-step-wizard>

	<br>

	<h2>Non-linear</h2>
	<n-step-wizard [orientation]="orientation" [steps]="steps" [linear]="false"></n-step-wizard>
	`,
})
export class StepWizardDemo {

	orientation = "horizontal";

	steps = [
		{
			text: "1. ONE",
			state: ["validated"]
		},
		{
			text: "2. TWO",
			state: ["partial"]
		},
		{
			text: "3. THREE",
			state: ["complete"]
		},
		{
			text: "4. FOUR",
			state: ["complete", "current"]
		},
		{
			text: "5. FIVE",
			state: ["error"]
		},
		{
			text: "6. SIX",
			state: ["current", "error"]
		}
	];
}
