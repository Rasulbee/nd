import { Component } from "@angular/core";
import { TestBed, ComponentFixture, fakeAsync, tick } from "@angular/core/testing";
import { By } from "@angular/platform-browser";
import { TranslateModule, TranslateLoader, TranslateFakeLoader } from "@ngx-translate/core";
import { StaticIconModule } from "./../icon/static-icon.module";

import { Pill } from "../pill-input/pill.component";
import { PillInput } from "../pill-input/pill-input.component";
import { DropdownList } from "./../dropdown/list/dropdown-list.component";
import { ScrollableList } from "./../dropdown/scrollable-list.directive";

@Component({
	template: `
		<n-pill-input
			[pills]="pills"
			[pillDirection]="pillDirection"
			(updatePills)="filterPills()"
			(submit)="demoSubmit($event)"
			[type]="type"
			placeholder="placeholder">
		</n-pill-input>`
})
class PillTestComponent {
	items = [
		{
			content: "one",
			selected: false
		},
		{
			content: "two",
			selected: false
		},
		{
			content: "three",
			selected: false
		}
	];
	pills = this.items.map(item => { item.selected = true; return item; });
	pillDirection = "row";
	type = "multi";

	filterPills() {
		this.pills = this.items.filter(item => item.selected);
	}

	demoSubmit(ev) {
		let index = this.items.indexOf(ev.after) + 1;
		this.items = [...this.items.slice(0, index), { content: ev.value, selected: true }, ...this.items.slice(index)];
		this.pills = this.items.filter(item => item.selected);
	}
}

describe("pill input", () => {
	let fixture: ComponentFixture<PillTestComponent>;

	beforeEach(() => {
		TestBed.configureTestingModule({
			declarations: [
				PillInput,
				Pill,
				DropdownList,
				PillTestComponent,
				ScrollableList
			],
			imports: [
				TranslateModule.forRoot({ loader: { provide: TranslateLoader, useClass: TranslateFakeLoader } }),
				StaticIconModule
			]
		});
	});

	it("should work", () => {
		fixture = TestBed.createComponent(PillTestComponent);

		expect(fixture.componentInstance instanceof PillTestComponent).toBe(true);
	});

	it("should display placeholder", () => {
		fixture = TestBed.createComponent(PillTestComponent);
		fixture.detectChanges();

		expect(fixture.nativeElement.querySelector(".input_placeholder").textContent.trim()).toEqual("placeholder");
	});

	it("should have user defined pills visible on init", () => {
		fixture = TestBed.createComponent(PillTestComponent);
		fixture.detectChanges();

		expect(fixture.componentInstance.pills[0].selected).toEqual(true);
		expect(fixture.componentInstance.pills[1].selected).toEqual(true);
	});

	it("should deselect a pill", () => {
		fixture = TestBed.createComponent(PillTestComponent);
		fixture.detectChanges();

		const closeButton = fixture.nativeElement.querySelector(".pill_close");
		closeButton.click();

		fixture.detectChanges();

		expect(fixture.componentInstance.pills[0].selected).toEqual(false);
		expect(fixture.componentInstance.pills[1].selected).toEqual(true);
	});

	it("should arrange pills in column format", () => {
		fixture = TestBed.createComponent(PillTestComponent);
		fixture.componentInstance.pillDirection = "column";
		fixture.detectChanges();

		expect(fixture.debugElement.query(By.css(".pill_input_wrapper")).nativeElement.querySelector("div").className).toContain("column");
	});

	it("should arrange pills in row format", () => {
		fixture = TestBed.createComponent(PillTestComponent);
		fixture.detectChanges();

		expect(fixture.debugElement.query(By.css(".pill_input_wrapper")).nativeElement.querySelector("div").className).not.toContain("column");
	});

	it("should update pill list when closing a pill", fakeAsync(() => {
		fixture = TestBed.createComponent(PillTestComponent);
		fixture.detectChanges();

		tick();
		fixture.detectChanges();

		const closeButton = fixture.debugElement.queryAll(By.css(".pill_close"));
		closeButton[0].nativeElement.click();

		expect(fixture.componentInstance.pills[0].content).toEqual("two");
	}));

	it("should create a pill on submit", () => {
		fixture = TestBed.createComponent(PillTestComponent);
		fixture.detectChanges();

		const input = fixture.debugElement.query(By.css(".input")).nativeElement;
		input.textContent = "test";
		input.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, key: "Enter" }));

		fixture.detectChanges();

		expect(fixture.componentInstance.pills[1].content).toEqual("test");
	});

	it("should expand input and show hidden pills", () => {
		fixture = TestBed.createComponent(PillTestComponent);
		fixture.componentInstance.pillDirection = "column";
		fixture.detectChanges();
		fixture.nativeElement.querySelector(".btn--link").click();
		fixture.detectChanges();

		expect(fixture.nativeElement.querySelector(".btn--link").textContent.trim()).toEqual("Hide");
		expect(fixture.nativeElement.querySelector("n-pill-input > div").className).toEqual("pill_input_wrapper expand-overflow");
	});

	it("should collapse input on Escape", () => {
		fixture = TestBed.createComponent(PillTestComponent);
		fixture.componentInstance.pillDirection = "column";
		fixture.detectChanges();
		fixture.nativeElement.querySelector(".btn--link").click();
		fixture.detectChanges();

		const input = fixture.debugElement.query(By.css(".input")).nativeElement;
		input.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, key: "Escape" }));

		fixture.detectChanges();

		expect(fixture.nativeElement.querySelector(".btn--link").textContent.trim()).toEqual("2 more");
		expect(fixture.nativeElement.querySelector("n-pill-input > div").className).toEqual("pill_input_wrapper");
	});

	it("should close a pill on Backspace", () => {
		fixture = TestBed.createComponent(PillTestComponent);
		fixture.detectChanges();

		const input = fixture.debugElement.query(By.css(".input")).nativeElement;
		input.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, key: "Backspace" }));

		fixture.detectChanges();

		expect(fixture.debugElement.queryAll(By.css("n-pill"))[0].nativeElement.querySelector("span").textContent.trim()).not.toEqual("one");
	});
});
