import { ListItem } from "./../dropdown/list-item.interface";
import {
	Component,
	EventEmitter,
	Output,
	Input,
	HostBinding
} from "@angular/core";


/**
 * Internal component that represents a single pill/selected item
 * @export
 * @class Pill
 */
@Component({
	selector: "n-pill",
	template: `
		<span><ng-content></ng-content></span>
		<button *ngIf="!disabled" class="pill_close" (click)="doRemove($event)" type="button">
			<n-static-icon icon="x" size="sm" classList="close_icon"></n-static-icon>
		</button>`
})
export class Pill {
	/**
	 * Set to `true` to disable pill
	 *
	 * @memberof Pill
	 */
	@Input() disabled = false;
	/** `ListItem` to render */
	@Input() item: ListItem;
	/** emits an empty event when the close button is clicked */
	@Output() remove = new EventEmitter();
	@HostBinding("attr.class") attrClass = "pill";
	/** close button handler */
	public doRemove(ev) {
		this.item.selected = false;
		ev.stopPropagation();
		this.remove.emit(this.item);
	}
}
