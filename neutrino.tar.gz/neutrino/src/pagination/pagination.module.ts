import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { TranslateModule } from "@ngx-translate/core";
import { FormsModule } from "@angular/forms";

import { Pagination } from "./pagination.component";
import { GotoPage } from "./goto-page.component";

export { PaginationModel } from "./pagination-model.class";
export { GotoPage } from "./goto-page.component";
export { Pagination } from "./pagination.component";

@NgModule({
	declarations: [
		GotoPage,
		Pagination
	],
	exports: [
		GotoPage,
		Pagination
	],
	imports: [
		CommonModule,
		TranslateModule,
		FormsModule
	]
})
export class PaginationModule {}
