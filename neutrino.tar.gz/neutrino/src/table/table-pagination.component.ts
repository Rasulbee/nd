import { Component } from "@angular/core";

import { Pagination } from "../pagination/pagination.module";

/**
 * TablePagination is a child component to the Table component.
 *
 * @deprecated from Neutrino 2.0 in favor of `n-pagination` from `Pagination` module.
 *
 * Add `PaginationModule` in addition to `TableModel` and use `n-pagination` instead. You can keep
 * everything else as is.
 *
 * ```html
 * <n-table-pagination [model]="model" (selectPage)="selectPage($event)"></n-table-pagination>
 * ```
 *
 * becomes
 *
 * ```html
 * <n-pagination [model]="model" (selectPage)="selectPage($event)"></n-pagination>
 * ```
 *
 * @export
 * @class TablePagination
 */
@Component({
	selector: "n-table-pagination",
	templateUrl: "../pagination/pagination.component.html"
})
export class TablePagination extends Pagination { }
