import {
	Component,
	Input,
	OnInit,
	Output,
	EventEmitter
} from "@angular/core";
import { DateTimeModel } from "./../date-time-model.class";
import { range } from "../../common/utils";

@Component({
	selector: "n-calendar-year-view",
	template: `
	<div class="calendar-view">
		<n-calendar-header [currentView]="currentView" header="yearOnlyRange"></n-calendar-header>
		<table class="calendar_grid">
			<tr
			class="grid_row--months"
			*ngFor="let i of range(-1, 2, -1)">
				<td
				*ngFor="let j of range(-1, 1, -1)"
				(click)="selectYear(i * 2 + j)"
				[ngClass]="{
					'today': isCurrentYear(i * 2 + j),
					'selected': isSelected(i * 2 + j),
					'range': inRange(i * 2 + j),
					'disabled': isDisabled(i * 2 + j)
				}">
					<div>
						<p>
							{{currentView.getFullYear() - (i * 2 + j)}}
						</p>
					</div>
				</td>
			</tr>
		</table>
	</div>
	`
})

export class CalendarYear implements OnInit {
	/**
	 * `DateTimeModel` to be used in this view.
	 *
	 * @type {DateTimeModel}
	 * @memberof CalendarMonths
	 */
	@Input() model: DateTimeModel;

	/**
	 * Allows user selection of a single date or a date range.
	 *
	 * In a `single` selection mode, every user click will select a year.
	 * `startDate` will be set to the beginning of the year selected and
	 * `endDate` will be set to the end of the last day of the same year.
	 *
	 * In a `range` selection mode, first user click selects a year, second user
	 * click updates `startDate` and `endDate` in a way that `startDate` becomes
	 * the start of the oldest of the clicked years and `endDate` becomes the end
	 * of the last day of the youngest of them.
	 *
	 * @type {("single" | "range")}
	 * @memberof CalendarMonths
	 */
	@Input() mode: "single" | "range" = "range";

	/**
	 * Emits an event when user clicks a date.
	 *
	 * Event contains `clicked` and `date`. `clicked` will be `"first"` or `"second"` when
	 * `mode` is `"range"`, or  `"single"` when mode is `"single"`
	 *
	 * @type {EventEmitter<any>}
	 * @memberof CalendarMonth
	 */
	@Output() dateSelected: EventEmitter<any> = new EventEmitter();

	/**
	 * `Date` being used in this view.
	 *
	 * @type {Date}
	 * @memberof CalendarMonths
	 */
	currentView = new Date();

	/**
	 * State to determine whether you are selecting `startDate` or `endDate`
	 *
	 * @memberof CalendarMonths
	 */
	rangeSelectionInProgress = false;

	ngOnInit() {
		const newCurrentView = new Date(this.model.startDate);

		if (newCurrentView && !isNaN(newCurrentView.getTime())) {
			this.currentView = newCurrentView;
		}
	}

	/**
	 * Wrapper for `range` function in utils because it cannot
	 * be directly used in template
	 *
	 * @param {number} stop
	 * @param {number} [start=0]
	 * @param {number} [step=1]
	 * @returns Array<any>
	 * @memberof CalendarMonths
	 */
	range(stop: number, start = 0, step = 1) {
		return range(stop, start, step);
	}

	/**
	 * Returns value indicating whether `year` is current year
	 *
	 * @param {number} yearIndex index of year in view
	 * @returns boolean
	 * @memberof CalendarYear
	 */
	isCurrentYear(yearIndex: number) {
		const now = new Date();
		const currentYear = this.currentView.getFullYear() - yearIndex; // Last year in the calendar view

		return currentYear === now.getFullYear();
	}

	/**
	 * Returns value indicating whether `year` is disabled
	 *
	 * @param {number} yearIndex index of year in view
	 * @returns boolean
	 * @memberof CalendarYear
	 */
	isDisabled(yearIndex: number) {
		const year = this.currentView.getFullYear() - yearIndex;
		return this.model.isDateDisabled(new Date(year, 1, 1));
	}

	/**
	 * Returns value indicating whether `year` is part of a range selection
	 *
	 * @param {number} yearIndex index of year in view
	 * @returns boolean
	 * @memberof CalendarYear
	 */
	inRange(yearIndex: number) {
		const year = this.currentView.getFullYear() - yearIndex;
		return this.model.isDateInRange(new Date(year, 1, 1));
	}

	/**
	 * Returns value indicating whether `year` is selected
	 *
	 * @param {number} yearIndex index of year in view
	 * @returns boolean
	 * @memberof CalendarYear
	 */
	isSelected(yearIndex: number) {
		if (!this.currentView) {
			return false;
		}

		const currentYearProvided = this.currentView.getFullYear() - yearIndex;

		for (let i = 0; i < 6; i ++) {
			const currentYearInView = this.currentView.getFullYear() - i;

			const isCurrentYearStart =
				this.model.startDate &&
				currentYearInView === this.model.startDate.getFullYear() &&
				currentYearProvided === this.model.startDate.getFullYear();

			const isCurrentYearEnd =
				this.model.endDate &&
				currentYearInView === this.model.endDate.getFullYear() &&
				currentYearProvided === this.model.endDate.getFullYear();

			if (isCurrentYearStart || isCurrentYearEnd) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Sets model's `startDate` and `endDate`
	 *
	 * @param {number} yearIndex index of year in view
	 * @memberof CalendarYear
	 */
	selectYear(yearIndex: number) {
		const selectedYear = this.currentView.getFullYear() - yearIndex;

		if (this.isDisabled(yearIndex)) {
			return;
		}

		if (this.mode === "range" && this.rangeSelectionInProgress) {
			this.rangeSelectionInProgress = false;
			this.model.selectYearEnd(new Date(selectedYear));
			this.model.endDate = new Date(selectedYear, 11, 31);

			this.dateSelected.emit({
				clicked: "second",
				date: this.model.endDate
			});

			if (this.model.startDate.getTime() > this.model.endDate.getTime()) {
				const tmp = this.model.startDate;
				this.model.startDate = this.model.endDate;
				this.model.endDate = tmp;
			}
		} else {
			this.rangeSelectionInProgress = this.mode === "range";  // set to true if mode is range
			this.model.selectYear(new Date(selectedYear, 1, 1));
			this.dateSelected.emit({
				clicked: this.mode === "range" ? "first" : "single",
				date: this.model.startDate
			});
		}
	}
}
