import {
	Component,
	Input,
	Output,
	EventEmitter
} from "@angular/core";

import { DateTimeModel } from "./date-time-model.class";

@Component({
	selector: "n-calendar",
	template: `
		<n-calendar-month-view
			[model]="model"
			[mode]="mode"
			[monthCount]="monthCount"
			(dateSelected)="dateSelected.emit($event)"
			*ngIf="view === 'month'">
		</n-calendar-month-view>

		<n-calendar-months-view
			[model]="model"
			[mode]="mode"
			(dateSelected)="dateSelected.emit($event)"
			*ngIf="view === 'months'">
		</n-calendar-months-view>

		<n-calendar-quarter-view
			[model]="model"
			[mode]="mode"
			(dateSelected)="dateSelected.emit($event)"
			*ngIf="view === 'quarter'">
		</n-calendar-quarter-view>

		<n-calendar-year-view
			[model]="model"
			[mode]="mode"
			(dateSelected)="dateSelected.emit($event)"
			*ngIf="view === 'year'">
		</n-calendar-year-view>
	`
})
export class Calendar {
	/**
	 * Select a calendar view for the `model`.
	 *
	 * @type {("month" | "months" | "quarter" | "year")}
	 * @memberof Calendar
	 */
	@Input() view: "month" | "months" | "quarter" | "year" = "month";

	/**
	 * Model which will be viewed.
	 *
	 * Data in the model will be reflected in the view. When users interact
	 * with the view, changes will be reflected in the model.
	 *
	 * @type {DateTimeModel}
	 * @memberof Calendar
	 */
	@Input() model: DateTimeModel;

	/**
	 * Allows user selection of a single date or a date range.
	 *
	 * Sets the underlaying modes for individual calendar views.
	 *
	 * @type {("single" | "range")}
	 * @memberof CalendarMonths
	 */
	@Input() mode: "single" | "range" = "range";

	/**
	 * How many months you wish to display in the calendar next to each other.
	 *
	 * You will normally want `1` or `2`, but who are we to limit you.
	 *
	 * @memberof Calendar
	 */
	@Input() monthCount = 1;

	/**
	 * Emits an event when user clicks a date.
	 *
	 * Event contains `clicked` and `date`. `clicked` will be `"first"` or `"second"` when
	 * `mode` is `"range"`, or  `"single"` when mode is `"single"`
	 *
	 * Example event:
	 * ```
	 * {
	 * 	clicked: "first",
	 * 	date: new Date()
	 * }
	 * ```
	 *
	 * @type {EventEmitter<any>}
	 * @memberof CalendarMonth
	 */
	@Output() dateSelected: EventEmitter<any> = new EventEmitter();

	// onKeyDown(evt, idx) {
	// 	console.log(evt, idx);
	// 	if (evt.key === "ArrowRight" && this.allButtons[idx + 1]) {
	// 		evt.preventDefault();
	// 		this.allButtons[idx + 1].focus();
	// 	} else if (evt.key === "ArrowLeft" && idx > 0) {
	// 		evt.preventDefault();
	// 		this.allButtons[idx - 1].focus();
	// 	} else if (evt.key === "ArrowUp" && idx - 7 >= 0) {
	// 		evt.preventDefault();
	// 		this.allButtons[idx - 7].focus();
	// 	} else if (evt.key === "ArrowDown" && this.allButtons[idx + 7]) {
	// 		evt.preventDefault();
	// 		this.allButtons[idx + 7].focus();
	// 	}
	// }
}
