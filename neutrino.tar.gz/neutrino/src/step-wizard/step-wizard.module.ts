import { IconModule, StaticIconModule } from "./../icon/icon.module";
import { DialogModule } from "../dialog/dialog.module";
import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { TranslateModule } from "@ngx-translate/core";

import { StepWizard } from "./step-wizard.component";
import { RouterModule } from "@angular/router";

@NgModule({
	declarations: [StepWizard],
	exports: [StepWizard],
	entryComponents: [StepWizard],
	imports: [
		CommonModule,
		TranslateModule,
		RouterModule,
		DialogModule,
		IconModule,
		StaticIconModule
	]
})
export class StepWizardModule {}
