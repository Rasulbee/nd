import {
	Component,
	OnInit,
	Input
} from "@angular/core";

import {
	Router,
	ActivatedRoute,
	RouterModule,
	NavigationEnd
} from "@angular/router";

@Component({
	selector: "n-step-wizard",
	template: `
	<div class="step-wizard--{{orientation}}">
		<ul class="step-wizard_steps">
			<li *ngFor="let step of steps; let i = index">
				<div *ngIf="orientation != 'limited-space--horizontal'; else stepWizardList">
					<ng-template [ngTemplateOutlet]="stepWizardList"></ng-template>
				</div>

				<ng-template #stepWizardList>
					<div [ngClass]="addState(step.state)">
						<div class="step-wizard_inner-circle">
							<peretz-icon *ngIf="step.state.includes('validated')" set="core_set" icon="check" size="sm"></peretz-icon>
							<peretz-icon *ngIf="step.state.includes('error')" set="alerts_status" icon="failure_fill" size="sm"></peretz-icon>
						</div>
					</div>
					<button [ngClass]="step.state.includes('current') ? 'btn-destyled' : 'btn--link'" type="button">{{step.text}}</button>
				</ng-template>
				<div *ngIf="i < steps.length - 1" class="step-wizard_line--{{lineState(i)}}"></div>
			</li>
		</ul>
	</div>
	`
})

export class StepWizard {
	@Input() orientation = "horizontal";
	@Input() linear = false;
	@Input() steps = [];

	lineState(index) {
		const validated = this.steps[index].state.includes("validated");
		const currentComplete = this.steps[index].state.includes("complete");
		const nextComplete =  this.steps[index + 1].state.includes("complete");

		if (this.linear && validated) {
			return "solid";
		} else if (!this.linear && currentComplete && nextComplete) {
			return "solid";
		} else {
			return "dashed";
		}
	}

	addState(stateArray) {
		return stateArray.reduce((obj, item) => {
			obj["step-wizard_circle--" + item] = true;
			return obj;
		}, {});
	}
}
