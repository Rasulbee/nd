import { Injectable } from "@angular/core";

@Injectable()
export class ConditionBuilderService {
	getEmptyCondition(attributes, operators, state = null) {
		return {
			conditionState: state || {
				attributes,
				operators
			},
			// attributes: attributes,
			operator: "",
			items: null
		};
	}

	getWrapAndAdd(condition, operator, attributes, operators) {
		return {
			conditionState: null,
			// attributes: attributes,
			operator: operator,
			items: [
				{
					conditionState: condition.state,
					// attributes: attributes,
					operator: "",
					items: null
				},
				this.getEmptyCondition(attributes, operators)
			]
		};
	}

	getDuplicated(condition, operators, operator = "and") {
		return {
			conditionState: null,
			// attributes: attributes,
			operator: operator,
			items: [
				{
					conditionState: condition.state,
					// attributes: attributes,
					operator: "",
					operators,
					items: null
				},
				{
					conditionState: condition.state,
					// attributes: attributes,
					operator: "",
					operators,
					items: null
				}
			]
		};
	}
}
