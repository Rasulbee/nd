import { Component } from "@angular/core";
import { TestBed, ComponentFixture } from "@angular/core/testing";
import { By	} from "@angular/platform-browser";
import { TranslateModule, TranslateLoader, TranslateFakeLoader } from "@ngx-translate/core";
import { StaticIconModule } from "./../icon/static-icon.module";

import { ListItem } from "./../dropdown/list-item.interface";
import { ComboBox } from "./combobox.component";
import { Pill } from "../pill-input/pill.component";
import { PillInput } from "../pill-input/pill-input.component";
import { DropdownList } from "./../dropdown/list/dropdown-list.component";
import { ScrollableList } from "./../dropdown/scrollable-list.directive";

@Component({
	template: `
	<n-combo-box
		placeholder="placeholder"
		[type]="type"
		[items]="items"
		[disabled]="disabled"
		(selected)="onSelect($event)"
		(submit)="onSubmit($event)"
		(close)="onClose()">
		<n-dropdown-list></n-dropdown-list>
	</n-combo-box>`
})
class ComboboxTestComponent {
	items = [{content: "one", selected: false}, {content: "two", selected: false}];
	type = "single";
	disabled = false;

	singleSelect: ListItem;
	multiSelect: ListItem;
	onSelect(ev) {
		this.singleSelect = ev.item;
		this.multiSelect = ev[0];
	}
	onSubmit(ev) {
		ev.value.selected = true;
		this.items = [...ev.items.slice(0, ev.index), ev.value, ...ev.items.slice(ev.index)];
	}
	onClose() {
		alert("EventEmitter works!");
	}
}

describe("Combo box", () => {
	let fixture: ComponentFixture<ComboboxTestComponent>;

	beforeEach(() => {
		TestBed.configureTestingModule({
			declarations: [
				ComboBox,
				PillInput,
				Pill,
				DropdownList,
				ComboboxTestComponent,
				ScrollableList
			],
			imports: [
				TranslateModule.forRoot({loader: {provide: TranslateLoader, useClass: TranslateFakeLoader}}),
				StaticIconModule
			]
		});
	});

	it("should work", () => {
		fixture = TestBed.createComponent(ComboboxTestComponent);

		expect(fixture.componentInstance instanceof ComboboxTestComponent).toBe(true);
	});

	it("should create a single selection", () => {
		fixture = TestBed.createComponent(ComboboxTestComponent);
		fixture.detectChanges();

		expect((fixture.debugElement.query(By.css("n-pill-input")).nativeElement.querySelector("[type='text']")).tagName).toEqual("INPUT");
	});

	it("should create a multi selection", () => {
		fixture = TestBed.createComponent(ComboboxTestComponent);
		fixture.componentInstance.type = "multi";
		fixture.detectChanges();

		// pill_input_wrapper is not there for single
		expect((fixture.debugElement.query(By.css("n-pill-input")).nativeElement.querySelector("div")).className).toEqual("pill_input_wrapper");
	});

	it("should have a placeholder that was defined by user for single", () => {
		fixture = TestBed.createComponent(ComboboxTestComponent);
		fixture.detectChanges();

		expect(fixture.nativeElement.querySelector("n-combo-box").getAttribute("placeholder")).toEqual("placeholder");
	});

	it("should have a placeholder that was defined by user for multi", () => {
		fixture = TestBed.createComponent(ComboboxTestComponent);
		fixture.componentInstance.type = "multi";
		fixture.detectChanges();

		expect(fixture.nativeElement.querySelector("n-combo-box").getAttribute("placeholder")).toEqual("placeholder");
	});

	it("should select an item and change placeholder value on select for single", () => {
		fixture = TestBed.createComponent(ComboboxTestComponent);
		fixture.detectChanges();

		let itemEl = fixture.debugElement.query(By.css("[role='option']"));
		itemEl.nativeElement.click();

		fixture.detectChanges();

		expect(itemEl.nativeElement.className).toEqual("selected");
		expect(fixture.componentInstance.singleSelect).toEqual({content: "one", selected: true});
		expect(fixture.nativeElement.querySelector("input").value).toBe("one");
	});

	it("should select an item and add input pills on select for multi", () => {
		fixture = TestBed.createComponent(ComboboxTestComponent);
		fixture.componentInstance.type = "multi";
		fixture.detectChanges();

		let itemEl = fixture.debugElement.query(By.css("[role='option']"));
		itemEl.nativeElement.click();

		fixture.detectChanges();

		expect(itemEl.nativeElement.className).toEqual("selected");
		expect(fixture.componentInstance.multiSelect).toEqual({content: "one", selected: true});
		expect(fixture.debugElement.queryAll(By.css("n-pill > span"))[0].nativeElement.textContent.trim()).toEqual("one");
	});

	it("should expand and filter the list when typing in text field for single", () => {
		fixture = TestBed.createComponent(ComboboxTestComponent);
		fixture.detectChanges();

		let element = fixture.debugElement.query(By.css("input")).nativeElement;
		element.value = "t";
		element.dispatchEvent(new KeyboardEvent("keyup"));

		fixture.detectChanges();

		expect(fixture.nativeElement.querySelector("[role='combobox']").getAttribute("aria-expanded")).toBe("true");
		expect(fixture.debugElement.queryAll(By.css("[role='option'] > span"))[0].nativeElement.textContent).toEqual("two");
	});

	it("should expand and filter the list when typing in text field for multi", () => {
		fixture = TestBed.createComponent(ComboboxTestComponent);
		fixture.componentInstance.type = "multi";
		fixture.detectChanges();

		let element = fixture.debugElement.query(By.css(".input")).nativeElement;
		element.textContent = "t";
		element.dispatchEvent(new KeyboardEvent("keyup"));

		fixture.detectChanges();

		expect(fixture.nativeElement.querySelector("[role='combobox']").getAttribute("aria-expanded")).toBe("true");
		expect(fixture.debugElement.queryAll(By.css("[role='option'] > span"))[0].nativeElement.textContent).toEqual("two");
	});

	it("should contain items defined by user for single", () => {
		fixture = TestBed.createComponent(ComboboxTestComponent);
		fixture.detectChanges();

		expect(fixture.debugElement.queryAll(By.css("[role='option'] > span"))[0].nativeElement.textContent).toEqual("one");
		expect(fixture.debugElement.queryAll(By.css("[role='option'] > span"))[1].nativeElement.textContent).toEqual("two");
	});

	it("should contain items defined by user for multi", () => {
		fixture = TestBed.createComponent(ComboboxTestComponent);
		fixture.componentInstance.type = "multi";
		fixture.detectChanges();

		expect(fixture.debugElement.queryAll(By.css("[role='option'] > span"))[0].nativeElement.textContent).toEqual("one");
		expect(fixture.debugElement.queryAll(By.css("[role='option'] > span"))[1].nativeElement.textContent).toEqual("two");
	});

	it("should create a disabled combobox for single", () => {
		fixture = TestBed.createComponent(ComboboxTestComponent);
		fixture.componentInstance.disabled = true;
		fixture.detectChanges();

		expect(fixture.debugElement.query(By.css("n-pill-input")).nativeElement.querySelector("[disabled]")).toBeTruthy();
	});

	it("should create a disabled combobox for multi", () => {
		fixture = TestBed.createComponent(ComboboxTestComponent);
		fixture.componentInstance.type = "multi";
		fixture.componentInstance.disabled = true;
		fixture.detectChanges();

		expect(fixture.debugElement.query(By.css("n-pill-input")).nativeElement.querySelector("div").className).toContain("disabled");
	});

	it("should open and close the list on click for single", () => {
		fixture = TestBed.createComponent(ComboboxTestComponent);

		const rootButton = fixture.nativeElement.querySelector(".btn--add-on");
		rootButton.click();

		fixture.detectChanges();

		expect(fixture.nativeElement.querySelector("[role='combobox']").getAttribute("aria-expanded")).toBe("true");
		expect(fixture.nativeElement.querySelector("n-static-icon").className).toEqual("open");

		spyOn(window, "alert");
		rootButton.click();
		fixture.detectChanges();

		expect(fixture.nativeElement.querySelector("[role='combobox']").getAttribute("aria-expanded")).toBe("false");
		expect(fixture.nativeElement.querySelector("n-static-icon").className).toBeFalsy();
		expect(window.alert).toHaveBeenCalledWith("EventEmitter works!");
	});

	it("should open and close the list on click for multi", () => {
		fixture = TestBed.createComponent(ComboboxTestComponent);
		fixture.componentInstance.type = "multi";
		fixture.detectChanges();

		const rootButton = fixture.nativeElement.querySelector(".btn--add-on");
		rootButton.click();

		fixture.detectChanges();

		expect(fixture.nativeElement.querySelector("[role='combobox']").getAttribute("aria-expanded")).toBe("true");
		expect(fixture.nativeElement.querySelector("n-static-icon").className).toEqual("open");

		spyOn(window, "alert");
		rootButton.click();
		fixture.detectChanges();

		expect(fixture.nativeElement.querySelector("[role='combobox']").getAttribute("aria-expanded")).toBe("false");
		expect(fixture.nativeElement.querySelector("n-static-icon").className).toBeFalsy();
		expect(window.alert).toHaveBeenCalledWith("EventEmitter works!");
	});

	it("should clear selection for multi", () => {
		fixture = TestBed.createComponent(ComboboxTestComponent);
		fixture.componentInstance.type = "multi";
		fixture.detectChanges();

		let itemEl = fixture.debugElement.queryAll(By.css("[role='option']"));
		itemEl[0].nativeElement.click();
		itemEl[1].nativeElement.click();

		fixture.detectChanges();
		fixture.debugElement.query(By.css(".clear-selection")).nativeElement.click();
		fixture.detectChanges();

		expect(itemEl[0].nativeElement.className).toBeFalsy();
		expect(itemEl[1].nativeElement.className).toBeFalsy();
	});

	it("should add new option on submit for multi", () => {
		fixture = TestBed.createComponent(ComboboxTestComponent);
		fixture.componentInstance.type = "multi";
		fixture.detectChanges();

		let element = fixture.debugElement.query(By.css(".input")).nativeElement;
		element.textContent = "test";
		element.dispatchEvent(new KeyboardEvent("keydown", {bubbles: true, key: "Enter"}));

		fixture.detectChanges();

		expect(fixture.debugElement.queryAll(By.css("n-pill > span"))[0].nativeElement.textContent.trim()).toEqual("test");
		expect(fixture.debugElement.query(By.css("[role='option']")).nativeElement.className).toEqual("selected");
	});

	it("should open menu on ArrowDown", () => {
		fixture = TestBed.createComponent(ComboboxTestComponent);
		fixture.detectChanges();

		const event = new KeyboardEvent("keydown", {bubbles: true, key: "ArrowDown"});
		const rootButton = fixture.nativeElement.querySelector(".btn--add-on");
		rootButton.dispatchEvent(event);

		fixture.detectChanges();

		expect(fixture.nativeElement.querySelector("[role='combobox']").getAttribute("aria-expanded")).toBe("true");
		expect(fixture.nativeElement.querySelector("n-static-icon").className).toEqual("open");
	});

	it("should close menu on escape", () => {
		fixture = TestBed.createComponent(ComboboxTestComponent);
		fixture.detectChanges();

		spyOn(window, "alert");

		const rootButton = fixture.nativeElement.querySelector(".btn--add-on");
		rootButton.click();

		const arrowDownEvent = new KeyboardEvent("keydown", {bubbles: true, key: "ArrowDown"});
		const escapeEvent = new KeyboardEvent("keydown", {bubbles: true, key: "Escape"});
		rootButton.dispatchEvent(arrowDownEvent);
		rootButton.dispatchEvent(escapeEvent);

		fixture.detectChanges();

		expect(fixture.nativeElement.querySelector("[role='combobox']").getAttribute("aria-expanded")).toBe("false");
		expect(fixture.nativeElement.querySelector("n-static-icon").className).toBeFalsy();
		expect(window.alert).toHaveBeenCalledWith("EventEmitter works!");
	});
});
