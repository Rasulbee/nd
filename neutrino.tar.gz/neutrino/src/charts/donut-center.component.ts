import { DonutCenter as ChartsDonutCenter } from "@peretz/charts/bundle/bundle.js";

export class DonutCenter extends ChartsDonutCenter {
	constructor(configs: any) {
		super(configs);
	}
}
