import {
	Component,
	Input,
	ElementRef,
	ChangeDetectorRef,
	HostBinding,
	AfterViewInit
} from "@angular/core";

@Component({
	selector: "n-progress-indicator",
	template: `
		<div class="progress-indicator-value">
			<ng-container *ngIf="showPercentage">{{value || 0}}%</ng-container>
			<ng-content></ng-content>
		</div>
		<svg viewBox="0 0 100 100">
			<g>
				<circle r="45" class="back-circle"></circle>
				<circle r="45" class="value-circle" transform="rotate(270.1)" [ngStyle]="{'stroke-dasharray': strokeDasharray}"></circle>
			</g>
		</svg>
	`
})
export class ProgressIndicator implements AfterViewInit {
	/**
	 * The value that reflects percent complete.
	 *
	 * Does not update for negative values. Shows as full for all values over 100.
	 *
	 * @memberof ProgressIndicator
	 */
	@Input() value: number;
	/**
	 * Toggle `true`/`false` to show/hide the percent complete.
	 * @memberof ProgressIndicator
	 */
	@Input() showPercentage = true;

	get strokeDasharray() {
		const radius = 45;
		const circumference = 2 * Math.PI * radius;
		return `${circumference * (this.value / 100)}, ${circumference}`;
	}

	@HostBinding("attr.class") get attrClass() {
		this.changeDetectorRef.detectChanges();
		return this.buildClass();
	}

	/**
	 * Creates an instance of ProgressIndicator
	 *
	 * @param {ElementRef} elementRef
	 * @memberof ProgressIndicator
	 */
	constructor(private elementRef: ElementRef, private changeDetectorRef: ChangeDetectorRef) {}

	ngAfterViewInit() {
		this.resize();
	}

	resize() {
		const clientRect = this.elementRef.nativeElement.parentNode.getBoundingClientRect();
		let containerWidth = clientRect.width;
		let containerHeight = clientRect.height;

		const frame = () => {
			const frameClientRect = this.elementRef.nativeElement.parentNode.getBoundingClientRect();

			if (Math.abs(containerWidth - frameClientRect.width) > 1 || Math.abs(containerHeight - frameClientRect.height) > 1) {
				containerWidth = frameClientRect.width;
				containerHeight = frameClientRect.height;
				this.elementRef.nativeElement.setAttribute("class", this.buildClass());
			}

			requestAnimationFrame(frame);
		};

		requestAnimationFrame(frame);
	}

	buildClass(baseClass = "progress-indicator") {
		const clientRect = this.elementRef.nativeElement.getBoundingClientRect();
		const minSize = Math.min(clientRect.width, clientRect.height);
		const breakpointSmall = 100;
		const breakpointLarge = 250;

		if (minSize <= breakpointSmall) { return `${baseClass}--sm`; }
		if (minSize >= breakpointLarge) { return `${baseClass}--lg`; }
		return baseClass;
	}
}
