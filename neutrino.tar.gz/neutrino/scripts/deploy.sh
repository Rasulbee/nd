#!/usr/bin/env bash

set -e # exit with nonzero exit code if anything fails

# exit with an error if the build fails
if [[ ${TRAVIS_TEST_RESULT=0} == 1 ]]; then
  exit 1;
fi

npm run build
cd dist

# AF_USER and AF_API_KEY are manually set on travis from info in artifactory
curl -u${AF_USER}:${AF_API_KEY} "https://na.artifactory.swg-devops.com/artifactory/api/npm/wce-peretz-npm-local/auth/peretz" > ~/.npmrc
npm publish
# extract the version from package json
version=$(node -e 'const package = require("./package.json"); console.log(package.version);')
name=$(node -e 'const package = require("./package.json"); console.log(package.name);')

# call our webhook with our new version
curl -d "{\"text\":\"\`$name@$version\` published :partyperetz:\"}" https://hooks.slack.com/services/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

# test all apps for new neutrino version (but only on master/cron)
if [[ ${TRAVIS_BRANCH} == "master" || ${TRAVIS_EVENT_TYPE} == 'cron' ]]; then
	curl -X POST http://9.26.137.210:7357/api/v1/tests
fi

# Move to the top level folder, and make a "deploy" directory
cd ../
mkdir deploy
cd deploy
git init

# Configure Git
git config user.name "Travis CI"
git config user.email "callums@ca.ibm.com"

# pull the upstream pages
git pull "git@github.ibm.com:peretz/neutrino.git" gh-pages

# copy to the master/alpha folder
if [[ ${TRAVIS_BRANCH} == "master" ]]; then
	cp -R ../demo/bundle/* ./
# copy to the beta folder
elif [[ ${TRAVIS_EVENT_TYPE} == "cron" ]]; then
	mkdir -p beta
	cp -R ../demo/bundle/* beta
# copy to the version folder
else
	mkdir -p $TRAVIS_BRANCH
	cp -R ../demo/bundle/* $TRAVIS_BRANCH
fi

# in this case we want the script to keep running, so we can actually check the $? (status) var
set +e
# Commit all the things into the repo
git add .
git commit -m "Deploy to GitHub Pages"

# Force push to gh-pages if there was something to commit
if [ $? -eq 0 ]; then
	git push --force "git@github.ibm.com:peretz/neutrino.git" master:gh-pages > /dev/null 2>&1
fi
# just to be sure we exit cleanly
exit 0;
