#!/usr/bin/env bash

set -e

# creates bundle, runs one time only, here for reference
# npm run g11n-pipeline -- create -b peretz -l en,de,es,fr,it,ja,ko,pt-BR,zh-Hans,zh-Hant

# requests translation
npm run g11n-pipeline -- import -b peretz -l en -f src/i18n/en.json -T

sleep 5s

for language in de es fr it ja ko pt-BR zh-Hans zh-Hant; do
	# downloads machine translated files
	npm run -s g11n-pipeline -- export -b peretz -l $language -F json -T > src/i18n/$language.json
done
