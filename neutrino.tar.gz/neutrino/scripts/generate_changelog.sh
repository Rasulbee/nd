#!/usr/bin/env bash

set -e

# This script is made to be run by travis

export CHANGELOG_GITHUB_TOKEN=bbf256d4a9f7d1996d22a63c8c33cf7cc058ac55
GITHUB_SITE=https://github.ibm.com
GITHUB_API=https://github.ibm.com/api/v3
GITHUB_USER=peretz
GITHUB_UPSTREAM=git@github.ibm.com:peretz/neutrino.git

github_changelog_generator --github-site $GITHUB_SITE --github-api $GITHUB_API -u $GITHUB_USER
gcg_ret_val=$?

if [ $gcg_ret_val -ne 0 ]
then
	exit gcg_ret_val
fi

# if changelog updated, add it
if [ "`git ls-files -m | grep CHANGELOG.md`" == "CHANGELOG.md" ]
then
	git add CHANGELOG.md
	git commit -m "Update CHANGELOG"
fi
