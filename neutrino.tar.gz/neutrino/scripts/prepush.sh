#!/usr/bin/env bash

set -e

GITHUB_UPSTREAM=git@github.ibm.com:peretz/neutrino.git

# Refresh code
git pull upstream master

if [ $? -ne 0 ]
then
	echo "Error: Couldn't pull from upstream."
	echo "Try running 'git remote add upstream $GITHUB_UPSTREAM' and try again."
	exit 1
fi


# generate changelog
./scripts/generate_changelog.sh

if [ $? -ne 0 ]
then
	echo "Error: Couldn't generate changelog."
	echo "Try running 'sudo gem install github_changelog_generator' and try again."
	exit 1
fi

npm test

#exit 1  # stops push from running, good for testing
