// Description of the test case that will be run.
describe("Accessibility Scan for ", function () {

    // Function to run before every testcase (it --> is a testcase)
    // This before function allows to add async support to a testcase.
    // The testcase will not run until the done function is called
    beforeEach(function () {
        // Extract the current jasmine DEFAULT_TIMEOUT_INTERVAL value to restore later on
        originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;

        // Set the DEFAULT_TIMEOUT_INTERVAL to 3min seconds, to allow for the DAP scan to finish.
        jasmine.DEFAULT_TIMEOUT_INTERVAL = 18000000;
	});

	const urls = [
		"",
		"banner",
		"button-menu",
		"chart",
		"combobox",
		"condition-builder",
		"dropdown",
		"forms",
		"icon",
		"list-group",
		"modal",
		"popover",
		"side-nav",
		"table",
		"tabs",
		"tooltip",
		"top-nav",
		"tree-view"
	];

	urls.forEach(url => {
		// The Individual testcase for each of the testcases.
    	// Note the done that is passed in, this is used to wait for asyn functions.
		it(`"neutrino/${url}" should have no accessibility violations`, function (done) {
			// Perform the accessibility scan using the AAT.getCompliance API
			AAT.getCompliance(`http://localhost:9000/#/${url}`, `neutrino/${url ? url : "landing-page"}`, function (results) {

				// Call the AAT.assertCompliance API which is used to compare the results with baseline object if we can find one that
				// matches the same label which was provided.
				var returnCode = AAT.assertCompliance(results);

				expect(returnCode).toBe(0);
				// If want to write results to console comment above expect and uncomment below expect line
				// expect(returnCode).toBe(0, AAT.stringifyResults(results));

				// Mark the testcases as done.
				done();
			});
		});
	});

    // Function to run after every testcase (it --> is a testcase)
    // This function will reset the DEFAULT_TIMEOUT_INTERVAL for a testcase in jasmine
    afterEach(function () {

        // Reset the Jasmine timeout
        jasmine.DEFAULT_TIMEOUT_INTERVAL = originalTimeout;

    });
});
