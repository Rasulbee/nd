module.exports = function (config) {
    // Set all the karma configurations
    config.set({

        // Base path that will be used to resolve all patterns (eg. files, exclude)
        // This can be set to anything, default is ""
        basePath: "a11y",

        // Start the browsers in this Array and run tests on them
        // Available browser launchers: https://npmjs.org/browse/keyword/karma-launcher
        // All theses browsers will be started when Karma starts, more info on url above.
        //browsers: ["Firefox", "Chrome"],
        // browsers: ["Chrome"],

        // Plugins for karma to load
        plugins: [
            `karma-*`,
            require(`@ibma/json2html/karma-json2html-Reporter`)
        ],

        browsers: ["ChromeCustom"],

        /* ---------------------- Start custom browser launchers ---------------------- */
        // Create a custom firefox launcher with some preferences set and extensions
        // installed, for this custom firefox launcher we set the following:
        //  Preference:
        //      blockautorefresh --> Disable meta refresh to avoid testcases from hanging
        customLaunchers: {
            FirefoxCustom: {
                // List the base browser launcher
                base: "Firefox",

                // Key value of all the preferences to be set before launch
                prefs: {
                    "accessibility.blockautorefresh": true
                }

            },
            ChromeCustom: {
                // List the base browser launcher
                base: "Chrome",

                flags: ["--disable-web-security", "-start-maximized"]

            }
        },

        /* ----------------------- End custom browser launchers ----------------------- */

        // Frameworks to use to run the tests that we define
        // Available frameworks: https://npmjs.org/browse/keyword/karma-adapter
        // For an additional frameworks, make sure to instll the plugins.
        frameworks: ["jasmine", "AAT"],

        // List of files / patterns to load in the browser
        // Additional details at: https://karma-runner.github.io/0.13/config/files.html
        // Note: Order matters, the order they are listed here is how they are loaded.
        // If you want to use html files in js make sure to load them first.
        files: [
            "tests/**/*.js",
            // If baselines are provided
            // "baselines/**/*.json"
        ],

        // List of files/patterns to exclude from loaded files.
        exclude: [],

        // Preprocess matching files before serving them to the browser
        // available preprocessors: https://npmjs.org/browse/keyword/karma-preprocessor
        // Note: Preprocessors may be transforming the files and file types that are available at run time.
        // Additional details at: https://karma-runner.github.io/0.13/config/preprocessors.html
        preprocessors: {
            // If baselines are needed
            // "baselines/**/*.json": ["AAT"]
        },

        // Test results reporter to use
        // possible values: "dots", "progress"
        // Available reporters: https://npmjs.org/browse/keyword/karma-reporter
        reporters: ["spec", "AAT", "notify", "json2html"],

        // json2html node module configurations
        json2htmlReporter: {
            outputFolder: "a11y/resultsHtml",
            // label: "CombinedReport"
          },

        // spec reporter configuration to make it a little more readable
        // More information available at: https://www.npmjs.com/package/karma-spec-reporter
        specReporter: {
            maxLogLines: 20, // limit number of lines logged per test
            suppressErrorSummary: false, // do not print error summary
            suppressFailed: false, // do not print information about failed tests
            suppressPassed: false, // do not print information about passed tests
            suppressSkipped: false, // do not print information about skipped tests
            showSpecTiming: true // print the time elapsed for each spec
        },

        // Optional Settings
        notifyReporter: {
            reportEachFailure: true, // Default: false, Will notify on every failed sepc
            reportSuccess: true, // Default: true, Will notify when a suite was successful
        },

        // web server port
        port: 9876,

        // Hostname for which the karma server will start on
        hostname: "localhost",

        // enable / disable colors in the output (reporters and logs)
        colors: true,

        // level of logging
        // possible values: config.LOG_DISABLE || config.LOG_ERROR || config.LOG_WARN || config.LOG_INFO || config.LOG_DEBUG
        logLevel: config.LOG_DISABLE,

        // enable / disable watching file and executing tests whenever any file changes
        autoWatch: false,

        // Continuous Integration mode
        // if true, Karma captures browsers, runs the tests and exits
        singleRun: true,

        // Concurrency level
        // how many browser should be started simultaneous
        concurrency: Infinity,

        browserNoActivityTimeout: 36000
    });
}
